# Test Utterances (should parse)

- "Driver, 7-iron, two putt par"
- "3 wood off the tee, soft pitching wedge to 15 feet, tap in for par"
- "Push drive, punch 5-iron out, wedge on, two putt bogey"
- "Hybrid, 8i, three-putt double"
- "PW to five feet, missed, tap-in par"
