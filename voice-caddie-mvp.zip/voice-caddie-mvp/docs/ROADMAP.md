# Roadmap (first 6 weeks – hobby pace)

## Milestones
- M1: Voice recap → parsed JSON (local) ✅ criteria in /docs/STORIES.md
- M2: GPS pins & map view
- M3: Stats (score, FIR/GIR, putts)
- M4: Polished UX + internal test (Play Console)

## Success criteria
- ≤10 interactions per round
- ≥85% recap parse accuracy on test utterances
- ≤15% battery drain for 18 holes (screen mostly off)
