## What
- 

## Why
- 

## How to test
- 

## Checklist
- [ ] Acceptance criteria met
- [ ] No crashes on device
- [ ] Added/updated tests
- [ ] Updated docs/README if needed
